import { useState, type FormEvent, type ChangeEvent } from "react";
import { Check, CreditCard, MessageCircle, FileText, Send, Phone } from "lucide-react";

interface FormData {
  confirmed: boolean;
  fullName: string;
  phone: string;
  address: string;
  quantity: string;
  invoice: string;
}

interface FormErrors {
  confirmed?: string;
  fullName?: string;
  phone?: string;
  address?: string;
  quantity?: string;
  invoice?: string;
}

const initialFormData: FormData = {
  confirmed: true,
  fullName: "",
  phone: "",
  address: "",
  quantity: "1",
  invoice: "",
};

const steps = [
  {
    number: "1",
    title: "Chuyển khoản",
    content: (
      <span>
        STK: <strong className="text-[#C62828] font-semibold">102345678</strong> -{" "}
        <strong className="text-[#C62828] font-semibold">BIDV</strong>; Chủ TK: HydrostructAi
      </span>
    ),
    icon: CreditCard,
  },
  {
    number: "2",
    title: "Nội dung chuyển khoản",
    content: (
      <span>
        Họ và tên + Số điện thoại <span className="text-[#D32F2F] font-medium">(xuất hóa đơn 100%)</span>
      </span>
    ),
    icon: FileText,
  },
  {
    number: "3",
    title: "Xác nhận qua Zalo",
    content: (
      <span>
        Gửi Bill chuyển khoản vào zalo{" "}
        <strong className="text-[#FF6F00] font-semibold">0374 874142</strong> để xác nhận
      </span>
    ),
    icon: MessageCircle,
  },
  {
    number: "4",
    title: "Đăng ký thông tin",
    content: "Điền đầy đủ thông tin theo biểu mẫu bên dưới",
    icon: FileText,
  },
];

function validatePhone(phone: string): boolean {
  const phoneRegex = /^(0[3|5|7|8|9])+([0-9]{8})$/;
  return phoneRegex.test(phone);
}

export default function Home() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (field: keyof FormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.confirmed) {
      newErrors.confirmed = "Vui lòng xác nhận đã chuyển khoản";
    }
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Vui lòng nhập họ và tên";
    }
    if (!formData.phone.trim()) {
      newErrors.phone = "Vui lòng nhập số điện thoại";
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = "Số điện thoại không hợp lệ (10 số, bắt đầu bằng 0)";
    }
    if (!formData.address.trim()) {
      newErrors.address = "Vui lòng nhập địa chỉ nhận hàng";
    }
    if (!formData.quantity || parseInt(formData.quantity) < 1) {
      newErrors.quantity = "Số lượng phải từ 1 trở lên";
    }
    if (!formData.invoice) {
      newErrors.invoice = "Vui lòng chọn một tùy chọn";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4" style={{ backgroundColor: "#F5F5F0" }}>
        <div
          className="w-full max-w-[680px] rounded-lg shadow-lg text-center py-16 px-8"
          style={{ backgroundColor: "#FFFFFF" }}
        >
          <div className="w-20 h-20 rounded-full bg-[#4CAF50] flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-[#1B5E20] mb-4">Đăng ký thành công!</h2>
          <p className="text-[#616161] mb-2">
            Cảm ơn bạn đã đăng ký. Chúng tôi sẽ liên hệ xác nhận trong vòng 24h.
          </p>
          <p className="text-[#FF6F00] font-medium">
            Liên hệ Zalo: 0374 874142
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-6 sm:py-10 px-0 sm:px-4" style={{ backgroundColor: "#F5F5F0" }}>
      <div className="mx-auto w-full max-w-[680px]">
        {/* Form Card */}
        <div
          className="bg-white rounded-none sm:rounded-lg shadow-md overflow-hidden"
          style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.08), 0 0 1px rgba(0,0,0,0.04)" }}
        >
          {/* Header */}
          <div
            className="px-6 sm:px-8 py-8 sm:py-10"
            style={{
              background: "linear-gradient(135deg, #0D3B10 0%, #1B5E20 60%, #2E7D32 100%)",
            }}
          >
            <h1 className="text-white text-xl sm:text-2xl font-bold uppercase tracking-wide leading-tight">
              Đăng Ký Bộ Công Cụ Quản Lý Dự Án Một Trang Giấy
            </h1>
            <p className="text-white/80 mt-3 text-sm sm:text-base">
              Bộ công cụ OPPM (One-Page Project Manager) áp dụng cho dự án đầu tư xây dựng
            </p>
            <div className="mt-5">
              <span
                className="inline-block bg-white px-5 py-2 rounded-full text-[#1B5E20] font-bold text-xl sm:text-2xl"
              >
                Giá: 595.000 VNĐ
              </span>
            </div>
            <p className="text-white/60 mt-3 text-xs sm:text-sm">
              (Có đầy đủ hóa đơn để thanh toán Công ty)
            </p>
          </div>

          {/* Product Description */}
          <div className="px-6 sm:px-8 py-5 border-b border-[#E0E0E0]">
            <p className="text-[#616161] text-sm leading-relaxed">
              Bộ công cụ bao gồm: Template Excel OPPM, Hướng dẫn sử dụng chi tiết, Ví dụ minh họa cho dự án xây dựng thực tế. 
              Giúp Ban quản lý dự án, Chủ đầu tư, Nhà thầu theo dõi tiến độ, chi phí, nhân sự trên một trang duy nhất.
            </p>
          </div>

          {/* Payment Steps */}
          <div className="px-6 sm:px-8 py-6 border-b border-[#E0E0E0] bg-[#FAFAFA]">
            <h3 className="text-[#212121] font-bold text-base mb-5">Các bước đặt hàng:</h3>
            <div className="relative pl-4">
              {/* Vertical connecting line */}
              <div
                className="absolute left-[19px] top-4 bottom-4 w-0.5 bg-[#E0E0E0]"
              />

              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div key={index} className="relative flex gap-4 mb-5 last:mb-0">
                    <div className="relative z-10 flex-shrink-0">
                      <div
                        className="w-10 h-10 rounded-full bg-[#FF6F00] flex items-center justify-center text-white font-bold text-base shadow-sm transition-transform hover:scale-105"
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                    </div>
                    <div className="pt-1">
                      <p className="font-semibold text-[#212121] text-sm">{step.title}</p>
                      <p className="text-[#616161] text-sm mt-0.5 leading-relaxed">{step.content}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Form Fields */}
          <form onSubmit={handleSubmit} className="px-6 sm:px-8 py-6">
            {/* Confirmation Field */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Bạn đã chuyển khoản và gửi bill xác nhận vào số zalo trên rồi chứ
                <span className="text-[#D32F2F] ml-1">*</span>
              </label>
              <div className="flex items-center gap-3 mt-2">
                <button
                  type="button"
                  onClick={() => handleChange("confirmed", !formData.confirmed)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-md border-2 text-sm font-medium transition-all ${
                    formData.confirmed
                      ? "bg-[#1B5E20] border-[#1B5E20] text-white"
                      : "bg-white border-[#E0E0E0] text-[#616161] hover:border-[#1B5E20]"
                  }`}
                >
                  {formData.confirmed && <Check className="w-4 h-4" />}
                  OK - Đã chuyển khoản
                </button>
              </div>
              {errors.confirmed && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.confirmed}</p>
              )}
            </div>

            {/* Full Name */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Họ và tên <span className="text-[#D32F2F]">*</span>
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e: ChangeEvent<HTMLInputElement>) => handleChange("fullName", e.target.value)}
                placeholder="Nhập họ và tên của bạn"
                className={`w-full h-12 px-4 rounded-md border text-sm outline-none transition-all placeholder:text-[#9E9E9E] ${
                  errors.fullName
                    ? "border-[#D32F2F] focus:ring-2 focus:ring-[#D32F2F]/15"
                    : "border-[#E0E0E0] focus:border-[#1B5E20] focus:ring-2 focus:ring-[#1B5E20]/15"
                }`}
              />
              {errors.fullName && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.fullName}</p>
              )}
            </div>

            {/* Phone */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Số điện thoại liên hệ <span className="text-[#D32F2F]">*</span>
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e: ChangeEvent<HTMLInputElement>) => handleChange("phone", e.target.value)}
                placeholder="Nhập số điện thoại"
                className={`w-full h-12 px-4 rounded-md border text-sm outline-none transition-all placeholder:text-[#9E9E9E] ${
                  errors.phone
                    ? "border-[#D32F2F] focus:ring-2 focus:ring-[#D32F2F]/15"
                    : "border-[#E0E0E0] focus:border-[#1B5E20] focus:ring-2 focus:ring-[#1B5E20]/15"
                }`}
              />
              {errors.phone && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.phone}</p>
              )}
            </div>

            {/* Address */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Địa chỉ nhận hàng <span className="text-[#D32F2F]">*</span>
              </label>
              <textarea
                value={formData.address}
                onChange={(e: ChangeEvent<HTMLTextAreaElement>) => handleChange("address", e.target.value)}
                placeholder="Nhập địa chỉ đầy đủ (số nhà, đường, phường/xã, quận/huyện, tỉnh/thành)"
                rows={3}
                className={`w-full px-4 py-3 rounded-md border text-sm outline-none transition-all placeholder:text-[#9E9E9E] resize-none ${
                  errors.address
                    ? "border-[#D32F2F] focus:ring-2 focus:ring-[#D32F2F]/15"
                    : "border-[#E0E0E0] focus:border-[#1B5E20] focus:ring-2 focus:ring-[#1B5E20]/15"
                }`}
              />
              {errors.address && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.address}</p>
              )}
            </div>

            {/* Quantity */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Số lượng bộ công cụ đặt mua <span className="text-[#D32F2F]">*</span>
              </label>
              <input
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e: ChangeEvent<HTMLInputElement>) => handleChange("quantity", e.target.value)}
                placeholder="Nhập số lượng"
                className={`w-full h-12 px-4 rounded-md border text-sm outline-none transition-all placeholder:text-[#9E9E9E] ${
                  errors.quantity
                    ? "border-[#D32F2F] focus:ring-2 focus:ring-[#D32F2F]/15"
                    : "border-[#E0E0E0] focus:border-[#1B5E20] focus:ring-2 focus:ring-[#1B5E20]/15"
                }`}
              />
              {errors.quantity && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.quantity}</p>
              )}
            </div>

            {/* Invoice */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-[#212121] mb-2">
                Bạn có cần xuất hóa đơn không? <span className="text-[#D32F2F]">*</span>
              </label>
              <div className="space-y-3 mt-2">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                      formData.invoice === "co"
                        ? "border-[#1B5E20] bg-[#1B5E20]"
                        : "border-[#E0E0E0] group-hover:border-[#1B5E20]"
                    }`}
                    onClick={() => handleChange("invoice", "co")}
                  >
                    {formData.invoice === "co" && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                  <span className="text-sm text-[#212121]">Có - Xuất hóa đơn VAT</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer group">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                      formData.invoice === "khong"
                        ? "border-[#1B5E20] bg-[#1B5E20]"
                        : "border-[#E0E0E0] group-hover:border-[#1B5E20]"
                    }`}
                    onClick={() => handleChange("invoice", "khong")}
                  >
                    {formData.invoice === "khong" && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                  <span className="text-sm text-[#212121]">Không - Không cần hóa đơn</span>
                </label>
              </div>
              {errors.invoice && (
                <p className="text-[#D32F2F] text-xs mt-1.5">{errors.invoice}</p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full h-[52px] bg-[#FF6F00] hover:bg-[#E65100] text-white font-bold text-base uppercase rounded-md flex items-center justify-center gap-2 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg active:translate-y-0"
              style={{ boxShadow: "0 2px 8px rgba(255,111,0,0.3)" }}
            >
              <Send className="w-5 h-5" />
              Gửi Đăng Ký
            </button>

            <p className="text-center text-[#9E9E9E] text-xs mt-4">
              Vui lòng kiểm tra kỹ thông tin trước khi gửi. Chúng tôi sẽ liên hệ xác nhận trong vòng 24h.
            </p>
            <p className="text-center text-[#1B5E20] text-xs mt-2 font-medium flex items-center justify-center gap-1">
              <Phone className="w-3.5 h-3.5" />
              Liên hệ Zalo: 0374 874142
            </p>
          </form>
        </div>

        {/* Footer */}
        <div className="text-center py-5">
          <p className="text-[#9E9E9E] text-xs">
            © 2025 HydrostructAI - Tư vấn Quản lý Dự án Đầu tư Xây dựng
          </p>
        </div>
      </div>
    </div>
  );
}
